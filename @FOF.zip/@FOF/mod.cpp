name = "514th Aux";					// Name of your mod
author = "author_mod";				// Affects Arma 3 Launcher, when the mod are loaded as local
picture = "FOF\Data\foflogo_CA.paa";
hideName = "false";
hidePicture = "false";
actionName = "";
action = "";
logo = "FOF\Data\foflogo_CA.paa";	// Logo displayed in the main menu
logosmall = "FOF\Data\foflogo_CA.paa";
icon = "FOF\Data\foflogo_CA.paa";


